// Bright Olaleye 20225524
package assignment1;

public class Person extends Entity {
	private String gender;
	public Person(String name, Date birthDate, String genderIn, double difficultyIn) {
		super(name, birthDate, difficultyIn);
		this.gender = genderIn;
	}
	public Person(Entity entity) { //copy constructor
		super(entity);
		gender = getGender(); //changed from entity.gender
	}
	public String getGender() {
		return gender;
	}
	
	public String entityType() {
		return "This is a person!\n";
	}
	public Person clone() {
		return new Person(this);
	}
	
	public String toString() {
		return(super.toString() + "Gender: " + gender + "\n");
	}


}

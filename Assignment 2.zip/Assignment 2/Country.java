// Bright Olaleye 20225524
package assignment1;

public class Country extends Entity {
	private String capital;
	public Country(String name, Date birthDate, String capital, double difficultyIn) {
		super(name, birthDate, difficultyIn);
		this.capital = capital;
	}
	public Country(Entity entity) { //copy constructor
		super(entity);
		capital = getCapital(); //changed from entity,getCapital
	}
	public String getCapital() {
		return capital;
	}
	
	public String entityType() {
		return "This entity is a country!\n";
	}
	public Country clone() {
		return new Country(this);
	}
	
	public String toString() {
		return(super.toString() + "Capital: " + capital +"\n");
	}


	
}

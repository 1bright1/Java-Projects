// Bright Olaleye 20225524
package assignment1;

public class Politician extends Person {
	private String party;
	
	public Politician(String name, Date birthDate, String genderIn, String partyIn, double difficultyIn) {
		super(name, birthDate, genderIn, difficultyIn);
		this.party = partyIn;
	}
	public Politician(Person person) { //copy constructor
		super(person);
		party = getParty();
	}
	public String getParty() {
		return party;
	}

	
	public String entityType() {
		return "This entity is a politician!\n";
	}
	public Politician clone() {
		return new Politician(this);
	}
	
	public String toString() {
		return(super.toString() + "Party: " + party + "\n");
	}

}

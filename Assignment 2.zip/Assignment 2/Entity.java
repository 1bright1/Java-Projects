// Bright Olaleye 20225524
package assignment1;

public abstract class Entity {
        private String name;
        private Date born;
        private double difficulty;
        
        
        public Entity(String name, Date birthDate, double difficultyIn) {
                this.name = name;
                this.born = new Date(birthDate); //no privacy leak
                this.difficulty = difficultyIn;
        }
        
        public Entity(Entity entity) {
                this.name = entity.name;
                this.born = new Date(entity.born); //no privacy leak
                this.difficulty = entity.difficulty; 
        }

        public String getName() { //accessor methods
                return name;
        }

        public Date getBorn() {
                return new Date(born);
        }
        public double getDifficulty() {
        	return difficulty;
        }
        
        public String toString() {
                return "Name: "+name+"\n"+"Born at: "+born.toString()+"\n";
        }
        public double getAwardedTicketNumber() {
        	return difficulty * 100;
        }
        

        public abstract String entityType(); //abstract method
        public abstract Entity clone();
        
        public String welcomeMessage() {
        	return "Welcome! Let's start the game! " + entityType();
        }
        public String closingMessage() {
        	return "Congratulation! The detailed information of the entity you guess is:\n" + toString();
        }


}


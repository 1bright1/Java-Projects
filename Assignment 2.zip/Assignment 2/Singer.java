// Bright Olaleye 20225524
package assignment1;

public class Singer extends Person {
	private String debutAlbum;
	private Date debutAlbumReleaseDate;
	
	public Singer(String name, Date birthDate, String genderIn, String debutAlbumIn, Date AlbumRelease, double difficultyIn) {
		super(name, birthDate, genderIn, difficultyIn);
		this.debutAlbum = debutAlbumIn;
		this.debutAlbumReleaseDate = AlbumRelease;
	}
	public Singer(Person person) { //copy constructor
		super(person);
		debutAlbum = getDebutAlbum(); 
		debutAlbumReleaseDate = getDebutAlbumReleaseDate(); 
	}
	public String getDebutAlbum() {
		return debutAlbum;
	}
	public Date getDebutAlbumReleaseDate() {
		return debutAlbumReleaseDate;
	}
	
	public String entityType() {
		return "This entity is a singer!\n";
	}
	public Singer clone() {
		return new Singer(this);
	}
	
	public String toString() {
		return(super.toString() + "Debut Album: " + debutAlbum + "\n" + "Release Date" + debutAlbumReleaseDate + "\n");
	}

}

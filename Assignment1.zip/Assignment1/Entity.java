//Bright Olaleye 20225524
public class Entity {
	private String name;
	private Date born;
	
	public Entity(String nameIn, Date strDate) { // constructor
		name = nameIn;
		born = new Date(strDate);
	}
	
	public String getName(){ // get name
		return name;
	}
	public Date getBorn() { // get date
		return new Date(born);
	}
	
	public void setDate(String nameIn, String strDate) { //set date
		this.name = nameIn;
		this.born = new Date(strDate);
	}
	
	public Entity(Entity entity ) { // deep copy constructor 
		this.name = entity.name;
		this.born = new Date(entity.born);
	}
	
	public String toString() {
		return (name + "," + "born on" + born);
	}
	
	public boolean equals(Entity entity) {
		if (entity == null) {
			return false;
		}
		else
			return(name.equals(entity.name) && born.equals(entity.born));
	}
}

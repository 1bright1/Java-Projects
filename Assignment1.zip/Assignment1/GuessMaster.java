//Bright Olaleye 20225524
import java.util.Random;
import java.util.Scanner;
public class GuessMaster {
	private int numberOfCandidateEntities;
	private Entity[] entities;
	
	public GuessMaster(){
		numberOfCandidateEntities = 0;
		entities = new Entity[100]; // set array to have a size of 100

	}
	
	public int getNumOfCandidate() {
		return numberOfCandidateEntities;
	}
	
	public void addEntity(Entity entity) {
		entities[numberOfCandidateEntities + 1] = new Entity(entity); // increse the number of candidate for new entity
		numberOfCandidateEntities++;
	}
	
	public void playGame(Entity entity) {
		System.out.println("Welcome to GuessMaster, where you will guess the birthdays for well-knowned people. To quit the game type quit.");
		System.out.println("When guessing birthdays, type in the following format: MM/DD/YYYY.");
		System.out.println("Guess the birthday of " + entity.getName());
		Scanner input = new Scanner(System.in);
		String userinput = input.next();
		Date obj = new Date(userinput);
		if (userinput== "quit") { // if user wants to quit go to next line
			System.exit(0);
		}
		else {
			if (obj.precedes(entity.getBorn())) { // check if they typed the correct date
				System.out.println("Incorrect. Try a later date"); 
			}
			else if (obj.equals(entity.getBorn())) {
				System.out.println("Bingo. You got it!!");
			}
			else {
				System.out.println("Incorrect. Try an earlier date");
			}
		}
	}
	
	public void playGame(int entityInd) { 
		playGame(entities[entityInd]);	
	}
	
	public void playGame() {
		int max = genRandomEntityInd();
		playGame(max);
	}

	int genRandomEntityInd() { // generate random number 
		Random random = new Random();
		int max = random.nextInt(numberOfCandidateEntities);
		return max;
	}
	
	public static void main(String[] args) {
		Entity trudeau = new Entity("Justin Trudeau", new Date("December", 25, 1971));
		Entity dion  = new Entity("Celine Dion", new Date("March", 30, 1968));
		Entity usa = new Entity("United States", new Date("July", 4, 1776));
		GuessMaster gm = new GuessMaster();
		gm.addEntity(trudeau);
		gm.addEntity(dion);
		gm.addEntity(usa);
		gm.playGame();
		
	
		
	}
	
}

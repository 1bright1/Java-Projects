
public class Activity {
	private int day;
	private int month;
	private int year;
	
	public Activity() {
		day = 1;
		month = 1;
		year = 1;
	}
	public Activity(int dayIn, int monthIn, int yearIn) {
		this();
		setDate(dayIn, monthIn, yearIn);
	}
	
	private boolean Valid(int dayIn, int monthIn, int yearIn) {
		if (yearIn > 0) {
			year = yearIn;
			
			if (monthIn > 0 && monthIn <= 12) {
				if (monthIn == 4 || monthIn == 6 || monthIn == 9 || monthIn == 11) {
					if (dayIn>0 && dayIn<=30) {
						return true;
					}
					else {
						dayIn =1;
						month = monthIn;
						//System.out.println(System.err);
						return false;
					}
				}
				else if (monthIn == 2) {
					if (dayIn>0 && dayIn <= 28) {
						return true;
					}
					else if (yearIn%4 == 0) {
						if(dayIn>0 && dayIn <=29) {
							return true;
						}
						else {
							dayIn = 1;
							month = monthIn;
							//System.out.println(System.err);
							return false;
						}
					}
					else {
						dayIn =1;
						month = monthIn;
						//System.out.println(System.err);
						return false;
					}
				}
				else {
					if (dayIn>0 && dayIn<=31) {
						return true;
					}
					else {
						dayIn =1;
						month = monthIn;
						//System.out.println(System.err);
						return false;
					}
				}

			}
			else {
				monthIn = 1;
				day = dayIn;
				//System.out.println(System.err);
				return false;
			}
		}
		else {
			yearIn = 1;
			month = monthIn;
			day = dayIn;
			//System.out.println(System.err);
			return false;
		}
	}
	
	public int getDay() {
		return day;
	}
	public int getMonth() {
		return month;
	}
	public int getYear() {
		return year;
	}

	
	public void setDate(int dayIn, int monthIn, int yearIn) {
		if (Valid(dayIn, monthIn, yearIn)) {
			this.day=dayIn;
			this.month=monthIn;
			this.year=yearIn;
		}
		else {
			System.out.println(System.err);
		}
	
	}
	public void printDate() {
		System.out.println(day + "." + month + "." + year);

	}
	

}


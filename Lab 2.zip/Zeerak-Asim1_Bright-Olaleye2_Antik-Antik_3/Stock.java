
public class Stock {
	private int day;
	private int month;
	private int year;
	private String name;
	private int []values= new int[7];
	
    public Stock() {
        day = 1;
        month = 1;
        year = 1;
        name = "";
        for (int i = 0; i<values.length; i++)
            values[i] = 0;
    }
   
    public Stock(int dayIn, int monthIn, int yearIn, String nameIn, int[] valIn){
    	this.name = nameIn;
        if(Valid(dayIn, monthIn, yearIn)){
        	if(valIn.length == 7) { 
            	for (int i = 0; i < valIn.length; i++){
                    if(valIn[i] < 0){
                        yearIn = year;
                        monthIn = month;
                        dayIn = day;
                        System.out.println("Error");
                    }else{
                    	this.values = valIn.clone();
                        this.year = yearIn;
                        this.month = monthIn;
                        this.day = dayIn;

                    }
                }
            }
        	else {
                this.year = yearIn;
                this.month = monthIn;
                this.day = dayIn;
        	}
        }
        else{
            System.out.println("Error");
            for (int i = 0; i<valIn.length; i++) {
            	values[i]=0;
            }
            yearIn = year;
            monthIn = month;
            dayIn = day;
        }
    }
    

	private boolean Valid(int dayIn, int monthIn, int yearIn) {
		if (yearIn > 0) {
			year = yearIn;
			
			if (monthIn > 0 && monthIn <= 12) {
				if (monthIn == 4 || monthIn == 6 || monthIn == 9 || monthIn == 11) {
					if (dayIn>0 && dayIn<=30) {
						return true;
					}
					else {
						dayIn =1;
						month = monthIn;
						//System.out.println(System.err);
						return false;
					}
				}
				else if (monthIn == 2) {
					if (dayIn>0 && dayIn <= 28) {
						return true;
					}
					else if (yearIn%4 == 0) {
						if(dayIn>0 && dayIn <=29) {
							return true;
						}
						else {
							dayIn = 1;
							month = monthIn;
							//System.out.println(System.err);
							return false;
						}
					}
					else {
						dayIn =1;
						month = monthIn;
						//System.out.println(System.err);
						return false;
					}
				}
				else {
					if (dayIn>0 && dayIn<=31) {
						return true;
					}
					else {
						dayIn =1;
						month = monthIn;
						//System.out.println(System.err);
						return false;
					}
				}

			}
			else {
				monthIn = 1;
				day = dayIn;
				//System.out.println(System.err);
				return false;
			}
		}
		else {
			yearIn = 1;
			month = monthIn;
			day = dayIn;
			//System.out.println(System.err);
			return false;
		}
	}
	
	public String getName(){
        return name;
    }

    public int getValue(int ind){
    	if(ind <=7) {
    		return values[ind];
    	}
    	else {
    		System.out.println("Error");
    		return -1;
    	}
//    	if(ind < 0 || ind > 7){
//            //System.out.println(System.err);
//            return -1;
//        } 
//    	else {
//    		return values[ind];
//    	}
//        int value=0;
//        for(int i = 0; i < values.length; i++) {
//            if(ind < 0 || ind > 7){
//                System.out.println(System.err);
//                return -1;
//            }
//            value = values[i];
//        }
//        return value;
    }

    public int getDay(){
        return day;
    }
    public int getMonth(){
        return month;
    }
    public int getYear(){
        return year;
    }

    public void setName(String nameIn){
    	this.name= nameIn;
    }

    public void setValue(int val, int ind){
    	if (ind >= 0 && ind< 7) {
    		if (val >= 0) {
    			this.values[ind]= val;
    		}
    		else {
    			System.out.println("Error");
    		}
    	}
    	else {
    		System.out.println("Error");
    	}
//        for (int i = 0; i < ind; i++){
//        	if(val < 0){            
//        		System.out.println(System.err);
//            }
//        	else{
//                 this.values[i]= val;
//            }
//        }
//    }
//    	else {
//    		System.out.println(System.err);
    }
  
    public int getMean() {
    	int count = 0;
    	for (int i = 0; i < values.length; i++) {
    		count+= values[i];
    	}
    	count/=values.length;
    	return count;
    }
    public void printStock(){
    	System.out.println(name + ":" + day + "." + month + "." + year +" ");
    	System.out.println("values: ");
    	for (int i = 0; i < values.length; i++) {
    		System.out.print(values[i] + ", ");
    	}
    	System.out.println("");
    }

	public void setDate(int dayIn, int monthIn, int yearIn) {
		if (Valid(dayIn, monthIn, yearIn)) {
			this.day=dayIn;
			this.month=monthIn;
			this.year=yearIn;
		}
		else {
			System.out.println(System.err);
		}
	
	}
//	public void printDate() {
//		System.out.println(day + "." + month + "." + year);
//
//	}
	

}

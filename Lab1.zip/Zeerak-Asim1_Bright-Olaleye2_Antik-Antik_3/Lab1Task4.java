package package1;
import java.util.Scanner;

public class Lab1Task4{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		
		int num = 0;
		
		System.out.print("Please enter a number: ");
		num = input.nextInt();
		
		input.close();
		
		System.out.println("-----------------------------------------------------------------------------------------");
		System.out.println("The multiplication between the number entered, and the integers from 1 to 20 are:");
		
		for(int i = 1; i <= 20; i++){
			if(i == 20)
				System.out.println((num * i));
			else
				System.out.print((num * i) + ", ");
		}
		System.out.println("-----------------------------------------------------------------------------------------");
	}
}
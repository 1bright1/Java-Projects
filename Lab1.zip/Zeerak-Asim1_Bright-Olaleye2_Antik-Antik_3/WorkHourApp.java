package package1;
import java.util.Scanner;

public class WorkHourApp{
	public int hoursperday = 0, numdays = 0;
	
	public static void main(String[] args){
		Scanner input = new Scanner (System.in);
		WorkHourApp obj = new WorkHourApp ();
		int z = 0, totalHrsWorked = 0;
		
		System.out.print("Please enter the amount of days you have worked: ");
		obj.numdays = input.nextInt();
		
		System.out.print("Please enter the amount of hours you work per day: ");
		obj.hoursperday = input.nextInt();
		
		input.close();
		
		totalHrsWorked = obj.hoursperday * obj.numdays;
		System.out.print("\n");
		
		for(int i = 1; i <= obj.numdays; i++){
			z = obj.hoursperday * i;
			System.out.println("Day " + i + " : " + z + " hours ");
		}
		System.out.println("--------------------------------------------------------------------------------------------------------------");
		System.out.println("The total amount of hours you have worked in " + (obj.numdays) + " days is " + (totalHrsWorked) + " hours.");
		System.out.println("Thank you for using WorkHourApp :D");
		System.out.println("--------------------------------------------------------------------------------------------------------------");
	}
}
package package1;
import java.util.Scanner; //Used for user input.

public class TaskInputOutput {
	public int x = 0, y = 0; //Public variable for .
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		TaskInputOutput obj = new TaskInputOutput();
		
		System.out.print("Enter a value for x: ");
		obj.x = input.nextInt();
		
		System.out.print("Enter a value for y: ");
		obj.y = input.nextInt();
		
		input.close();
		
		int a = obj.x + obj.y, m = obj.x * obj.y;
		
		System.out.println(obj.x + " + " + obj.y + " = " + a);
		System.out.println(obj.x + " * " + obj.y + " = " + m);
	}
}

package package1;

public class HelloWorld {
public static void main (String[] args){
	System.out.println("Hello My friends in ELEC 279");
}
}

package package1;
import java.util.Date;
public class DateAppTask {

	public static void main(String[] args) {
		int min = 10, max = 20, average = 5, count = 1;
		String myrole = "Driver";
		byte myFirstByte = 22;
		double pi = 3.14159;
		char myChar = 'N';
		
		Date todaysdate = new Date();
		//System.out.println(todaysdate);
		System.out.println("I am now the " + myrole);
		System.out.println("Our minimum score is " + min);
		System.out.println("We have a byte " + myFirstByte);
		System.out.println("And double type is " + pi);
		System.out.println("A char looks like " + myChar);
		
		while(count <=10) {
			System.out.println(todaysdate);
			count += 1;
		}
		
		for(int count2 = 0; count2 <= 25; count2++) {
			System.out.println(todaysdate);
		}
		
		for(int i = 0; i <= 5; i++) {
			for(int j = 0; j <= 10; j++) {
				System.out.println(todaysdate);
			}
		}
	}
}
